# Yawmiyyat Android app

Personal Android WebView wrapper for the Yawmiyyat checklist prototype.

Build: GitHub Actions -> Build Yawmiyyat APK -> Run workflow. Download the `Yawmiyyat-debug-APK` artifact.

Important: this first APK stores records locally on this device using WebView local storage. Cloud backup, Google sign-in, encrypted app lock, and data export/import are not implemented in this build. Do not uninstall or clear app data until a tested backup/export feature is added.
