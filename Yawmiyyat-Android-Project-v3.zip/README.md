# Yawmiyyat Android (development build)

This is an early Android WebView wrapper around the current Yawmiyyat HTML prototype.

## Build
GitHub Actions workflow: `.github/workflows/build-apk.yml` builds a debug APK and uploads it as an artifact.

## Current limitations (important)
- The app currently stores records in WebView local storage on this device.
- Google Sign-In, cloud backup/restore, password lock, PDF/Excel export, and full theme settings are not implemented yet.
- Hind Siliguri is loaded from Google Fonts when internet is available; system fallback is used offline.
- Do not clear app data or uninstall before exporting/backing up records. No cloud backup exists yet.

This is not a production-ready release. Test before relying on it for permanent records.
